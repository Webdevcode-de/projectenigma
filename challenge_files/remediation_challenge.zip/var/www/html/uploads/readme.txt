ACME Corp Upload Guidelines
- Max file size: 50 MB
- Allowed: jpg, png, gif, pdf, docx, txt
- No executables or scripts
- Files scanned by ClamAV
