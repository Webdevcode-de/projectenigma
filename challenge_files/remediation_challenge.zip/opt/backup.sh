#!/bin/bash
# Nightly backup at 02:00
BACKUP_DIR="/var/backups/$(date +%Y%m%d)"
mkdir -p "$BACKUP_DIR"
tar -czf "$BACKUP_DIR/www.tar.gz" /var/www/html/
echo "Backup: $BACKUP_DIR"
