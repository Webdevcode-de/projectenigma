#!/bin/bash
# Health monitor
STATUS=$(curl -s -o /dev/null -w "%{http_code}" http://localhost/)
if [ "$STATUS" != "200" ]; then systemctl restart nginx; fi
