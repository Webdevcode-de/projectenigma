/tmp &mdash; cleared on reboot (tmpfs)
