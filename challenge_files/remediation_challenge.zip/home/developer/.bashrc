alias ll='ls -alF'
alias cls='clear'
export EDITOR=nano
