alias ll='ls -alF'
alias cls='clear'
export EDITOR=nano
export PS1='\u@\h:\w\$ '
