ls -la /var/www/html/uploads/
cat backup_cache.php
ls /opt/
cat /opt/persistence.sh
cat /etc/cron.d/syscheck
tail -f /var/log/nginx/access.log | grep 198.51.100.42
apt install -y clamav rkhunter
clamscan /var/www/html/uploads/
cat /etc/hosts.deny
curl -s http://51.222.15.99:8443/payload
ls -la /opt/
cat /opt/.sys_update.lock
rm /opt/.sys_update.lock
rm /opt/persistence.sh
rm /etc/cron.d/syscheck
rm /var/www/html/uploads/backup_cache.php
echo 'Server clean. Need to report to boss.' > ~/notes.txt
