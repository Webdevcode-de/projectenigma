#!/bin/bash
echo "[*] Checking for unauthorized cron jobs..."
grep -r "persistence" /etc/cron* /var/spool/cron/ 2>/dev/null
echo "[*] Scanning for webshells..."
find /var/www/html/ -name "*.php" -type f 2>/dev/null
echo "[*] Done."
