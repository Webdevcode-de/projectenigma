apt update && apt upgrade -y
ufw enable && ufw allow 2222/tcp && ufw allow 80/tcp
systemctl enable nginx
reboot
